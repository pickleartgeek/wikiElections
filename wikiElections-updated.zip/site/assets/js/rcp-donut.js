/**
 * RCPDonut
 * ---------
 * A donut/ring chart in the RealClearPolitics "poll average" style:
 * title, a yellow "+X.X" lead pill, a colored ring (top candidates get
 * their own arc, everyone else pools into a neutral "field" arc), pill
 * labels on the ring, and a dot-legend underneath.
 */

const RCPDonut_reg = new Map();
const _rc = c => (typeof TK_col === 'function' ? TK_col(c) : c);
function RCPDonut_render(container, opts) {
  RCPDonut_reg.set(container, opts);
  const { title, segments, leadLabel, leadValue, leadColor, size = 260, href } = opts;
  // segments: [{ name, color, pct }], pct in 0-1, should sum to <= 1

  // strokeWidth has to be known before r, since r needs to leave room for
  // half the ring's own stroke width inside the viewBox -- the old code
  // computed r first from a flat magic-number margin (18px) that didn't
  // scale with the stroke, so on the default 260px size the ring's outer
  // edge (r + strokeWidth/2) actually exceeded the viewBox half-width and
  // got clipped by the SVG's own bounds.
  const strokeWidth = Math.max(28, size * 0.16);
  const ringPad = 4; // small breathing-room margin beyond the stroke itself
  const r = size / 2 - strokeWidth / 2 - ringPad;
  const cx = size / 2, cy = size / 2;
  const circumference = 2 * Math.PI * r;

  let offset = 0;
  let arcs = '';
  let labels = '';
  segments.forEach(seg => {
    const len = seg.pct * circumference;
    const dashArray = `${len} ${circumference - len}`;
    const rotation = (offset / circumference) * 360 - 90;
    arcs += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${_rc(seg.color)}"
      stroke-width="${strokeWidth}" stroke-dasharray="${dashArray}" stroke-dashoffset="0"
      transform="rotate(${rotation} ${cx} ${cy})" stroke-linecap="butt"/>`;

    if (seg.pct > 0.03) {
      const midAngle = ((offset + len / 2) / circumference) * 2 * Math.PI - Math.PI / 2;
      const lx = cx + Math.cos(midAngle) * r;
      const ly = cy + Math.sin(midAngle) * r;
      const pctText = `${(seg.pct * 100).toFixed(1)}%`;
      const textW = 20 + pctText.length * 7.5;
      labels += `
        <g transform="translate(${lx} ${ly})">
          <rect x="${-textW / 2}" y="-13" width="${textW}" height="26" rx="13" fill="var(--surface, #fff)" stroke="${_rc(seg.color)}" stroke-width="2"/>
          <text x="0" y="5" text-anchor="middle" font-size="13" font-weight="800" fill="${_rc(seg.color)}" font-family="var(--font-spinner-display, sans-serif)">${pctText}</text>
        </g>`;
    }
    offset += len;
  });

  const legendHtml = segments.filter(s => s.pct > 0).map(s =>
    `<span class="rcp-donut-legend-item"><span class="rcp-donut-legend-dot" style="background:${_rc(s.color)}"></span>${s.name}</span>`
  ).join('');

  const leadValueText = typeof leadValue === 'number' ? leadValue.toFixed(1) : leadValue;
  const badgeColor = leadColor || (segments[0] && segments[0].color) || '#2e6fdb';

  const inner = `
      ${title ? `<div class="rcp-donut-title">${title}</div>` : ''}
      ${leadLabel ? `<div class="rcp-donut-lead"><span class="rcp-donut-lead-name">${leadLabel}</span><span class="rcp-donut-lead-badge" style="background:${_rc(badgeColor)}">+${leadValueText}</span></div>` : ''}
      <svg viewBox="0 0 ${size} ${size}" width="100%" style="display:block; max-width:${size}px; margin:0 auto;">
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="var(--line, #e9e7dd)" stroke-width="${strokeWidth}"/>
        ${arcs}
        ${labels}
      </svg>
      <div class="rcp-donut-legend">${legendHtml}</div>`;

  container.innerHTML = href
    ? `<a class="rcp-donut-card rcp-donut-link" href="${href}">${inner}</a>`
    : `<div class="rcp-donut-card">${inner}</div>`;
}

/**
 * Convenience: build a top-2-plus-field donut from a BaseCalc aggregate.
 */
function RCPDonut_fromAggregate(container, agg, registry, title, href) {
  const sorted = agg.sorted;
  if (!sorted.length) {
    container.innerHTML = '<div class="small-muted" style="padding:16px;">No polling yet.</div>';
    return;
  }
  const top = sorted.slice(0, 2);
  const rest = sorted.slice(2);
  const fieldPct = rest.reduce((a, [, v]) => a + v, 0);

  const segments = top.map(([id, pct]) => ({
    name: TSR_candidateName(registry, id),
    color: TSR_candidateColor(registry, id),
    pct
  }));
  if (fieldPct > 0.005) segments.push({ name: 'Field / Undecided', color: '#c9c7bb', pct: fieldPct });

  const leadName = TSR_candidateName(registry, top[0][0]);
  const leadValue = top.length > 1 ? (top[0][1] - top[1][1]) * 100 : top[0][1] * 100;
  const leadColor = TSR_candidateColor(registry, top[0][0]);

  RCPDonut_render(container, { title, segments, leadLabel: leadName, leadValue, leadColor, href });
}

/** Donut from sorted [[id, share], ...]: top N get their own arc, the rest pool into "Field". */
function RCPDonut_fromPairs(container, pairs, nameOf, colorOf, title, opts) {
  opts = opts || {};
  const total = pairs.reduce((a, [, v]) => a + v, 0) || 1;
  const n = opts.top || 4, top = pairs.slice(0, n), rest = pairs.slice(n);
  const segments = top.map(([id, v]) => ({ name: nameOf(id), color: colorOf(id), pct: v / total }));
  const f = rest.reduce((a, [, v]) => a + v, 0) / total;
  if (f > 0.005) segments.push({ name: opts.fieldLabel || 'Field', color: '#c9c7bb', pct: f });
  const lead = top.length > 1 ? (top[0][1] - top[1][1]) / total * 100 : top[0][1] / total * 100;
  RCPDonut_render(container, { title, segments, leadLabel: nameOf(top[0][0]), leadValue: lead, leadColor: colorOf(top[0][0]), size: opts.size || 260, href: opts.href });
}

if (typeof MutationObserver !== 'undefined' && typeof document !== 'undefined') {
  new MutationObserver(() => RCPDonut_reg.forEach((o, el) => { if (document.body.contains(el)) RCPDonut_render(el, o); }))
    .observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme'] });
}

if (typeof window !== 'undefined') {
  window.RCPDonut_fromPairs = RCPDonut_fromPairs;
  window.RCPDonut_render = RCPDonut_render;
  window.RCPDonut_fromAggregate = RCPDonut_fromAggregate;
}
